database name: lunahlabs
database host: localhost
database user: root
database pass: 

The database password is empty

use the `lunahlabs.sql` file to create the database
